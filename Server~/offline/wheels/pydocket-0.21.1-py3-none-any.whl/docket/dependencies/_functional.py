"""Functional dependencies: Depends and Shared."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from contextlib import AbstractAsyncContextManager, AbstractContextManager
from typing import Any, TypeVar, cast, overload

from uncalled_for import (
    DependencyFactory,
    Shared as Shared,
    SharedContext as SharedContext,
)
from uncalled_for.functional import _Depends as _UncalledForDepends

# Re-export _parameter_cache from uncalled-for so that docket and uncalled-for
# share one cache dict.  FastMCP clears `docket.dependencies._parameter_cache`
# after mutating function signatures, so this must be the same object that
# uncalled-for's get_dependency_parameters uses internally.
from uncalled_for.introspection import (
    _parameter_cache as _parameter_cache,
    get_dependency_parameters,
)

from ._contextual import _TaskArgument

R = TypeVar("R")

DependencyFunction = DependencyFactory


class _Depends(_UncalledForDepends[R]):
    """Docket's call-scoped dependency with TaskArgument inference."""

    async def _resolve_parameters(
        self,
        function: Callable[..., Any],
    ) -> dict[str, Any]:
        stack = self.stack.get()
        arguments: dict[str, Any] = {}
        parameters = get_dependency_parameters(function)

        for parameter, dependency in parameters.items():
            if isinstance(dependency, _TaskArgument) and not dependency.parameter:
                dependency.parameter = parameter

            arguments[parameter] = await stack.enter_async_context(dependency)

        return arguments


@overload
def Depends(dependency: Callable[..., AbstractAsyncContextManager[R]]) -> R: ...
@overload
def Depends(dependency: Callable[..., AbstractContextManager[R]]) -> R: ...
@overload
def Depends(dependency: Callable[..., Awaitable[R]]) -> R: ...
@overload
def Depends(dependency: Callable[..., R]) -> R: ...
def Depends(dependency: DependencyFactory[R]) -> R:
    """Include a user-defined function as a dependency.  Dependencies may be:
    - Synchronous functions returning a value
    - Asynchronous functions returning a value (awaitable)
    - Synchronous context managers (using @contextmanager)
    - Asynchronous context managers (using @asynccontextmanager)

    If a dependency returns a context manager, it will be entered and exited around
    the task, giving an opportunity to control the lifetime of a resource.

    **Important**: Synchronous dependencies should NOT include blocking I/O operations
    (file access, network calls, database queries, etc.). Use async dependencies for
    any I/O. Sync dependencies are best for:
    - Pure computations
    - In-memory data structure access
    - Configuration lookups from memory
    - Non-blocking transformations

    Examples:

    ```python
    # Sync dependency - pure computation, no I/O
    def get_config() -> dict:
        # Access in-memory config, no I/O
        return {"api_url": "https://api.example.com", "timeout": 30}

    # Sync dependency - compute value from arguments
    def build_query_params(
        user_id: int = TaskArgument(),
        config: dict = Depends(get_config)
    ) -> dict:
        # Pure computation, no I/O
        return {"user_id": user_id, "timeout": config["timeout"]}

    # Async dependency - I/O operations
    async def get_user(user_id: int = TaskArgument()) -> User:
        # Network I/O - must be async
        return await fetch_user_from_api(user_id)

    # Async context manager - I/O resource management
    from contextlib import asynccontextmanager

    @asynccontextmanager
    async def get_db_connection():
        # I/O operations - must be async
        conn = await db.connect()
        try:
            yield conn
        finally:
            await conn.close()

    @task
    async def my_task(
        params: dict = Depends(build_query_params),
        user: User = Depends(get_user),
        db: Connection = Depends(get_db_connection),
    ) -> None:
        await db.execute("UPDATE users SET ...", params)
    ```
    """
    return cast(R, _Depends(dependency))
